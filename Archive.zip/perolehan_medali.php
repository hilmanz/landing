
<div id="medaliReport">
    <div class="medaliReport">
        <div class="iconMedali"></div>
        <div class="head">
            <h1>MEDALI PER KONTINGEN</h1>
      	    <a href="javascript:void(0)" class="iconRefresh" id="refreshDiv">&nbsp;</a>
        </div>
        <div class="row bgGrey">
            <div class="col1"><span>KONTINGEN</span></div>
            <div class="col2"><small>Emas</small><span class="medaliEmas">&nbsp;</span></div>
            <div class="col2"><small>Perak</small><span class="medaliPerak">&nbsp;</span></div>
            <div class="col2"><small>Perunggu</small><span class="medaliPerunggu">&nbsp;</span></div>
        </div><!-- end .row -->
        <div class="row first">
            <div class="col1"><span>DKI Jakarta</span></div>
            <div class="col2"><span>56</span></div>
            <div class="col2"><span>86</span></div>
            <div class="col2"><span>24</span></div>
        </div><!-- end .row -->
        <div  class="jcarousellite">
        <ul>
            <li>
            <div class="row">
                <div class="col1"><span>Sumatera Barat</span></div>
                <div class="col2"><span>50</span></div>
                <div class="col2"><span>44</span></div>
                <div class="col2"><span>12</span></div>
            </div><!-- end .row -->
            <div class="row">
                <div class="col1"><span>Jawa Barat</span></div>
                <div class="col2"><span>50</span></div>
                <div class="col2"><span>44</span></div>
                <div class="col2"><span>12</span></div>
            </div><!-- end .row -->
            <div class="row">
                <div class="col1"><span>Yogyakarta</span></div>
                <div class="col2"><span>50</span></div>
                <div class="col2"><span>44</span></div>
                <div class="col2"><span>12</span></div>
            </div><!-- end .row -->
            <div class="row">
                <div class="col1"><span>Kalimantan Barat</span></div>
                <div class="col2"><span>50</span></div>
                <div class="col2"><span>44</span></div>
                <div class="col2"><span>12</span></div>
            </div><!-- end .row -->
            <div class="row">
                <div class="col1"><span>Kalimantan Timur</span></div>
                <div class="col2"><span>50</span></div>
                <div class="col2"><span>44</span></div>
                <div class="col2"><span>12</span></div>
            </div><!-- end .row -->
            </li>
            <li>
            <div class="row">
                <div class="col1"><span>Yogyakarta</span></div>
                <div class="col2"><span>50</span></div>
                <div class="col2"><span>44</span></div>
                <div class="col2"><span>12</span></div>
            </div><!-- end .row -->
            <div class="row">
            <div class="row">
                <div class="col1"><span>Sumatera Barat</span></div>
                <div class="col2"><span>50</span></div>
                <div class="col2"><span>44</span></div>
                <div class="col2"><span>12</span></div>
            </div><!-- end .row -->
                <div class="col1"><span>Kalimantan Barat</span></div>
                <div class="col2"><span>50</span></div>
                <div class="col2"><span>44</span></div>
                <div class="col2"><span>12</span></div>
            </div><!-- end .row -->
            <div class="row">
                <div class="col1"><span>Kalimantan Timur</span></div>
                <div class="col2"><span>50</span></div>
                <div class="col2"><span>44</span></div>
                <div class="col2"><span>12</span></div>
            </div><!-- end .row -->
            <div class="row">
                <div class="col1"><span>Jawa Barat</span></div>
                <div class="col2"><span>50</span></div>
                <div class="col2"><span>44</span></div>
                <div class="col2"><span>12</span></div>
            </div><!-- end .row -->
            </li>
        </ul>
        </div><!-- end .jcarousellite -->
    </div><!-- end .medaliReport -->
</div><!-- end #medaliReport -->